/*1307981658,169775556*/

if (window.CavalryLogger) { CavalryLogger.start_js(["NJtdf"]); }

onloadRegister(function(){copy_properties(AsyncRequest.prototype,{setNectarModuleData:function(c){if(this.method=='POST'){var d=Env.module;if(c&&d===undefined){var b={fbpage_fan_confirm:1};var e=null;for(var a=c;a&&a!=document.body;a=a.parentNode){if(!a.id||typeof a.id!=='string')continue;if(a.id.startsWith('pagelet_')){d=a.id;break;}if(!e&&b[a.id])e=a.id;}if(d===undefined&&e)d=e;}if(d!==undefined){if(this.data.nctr===undefined)this.data.nctr={};this.data.nctr._mod=d;}}},setNectarImpressionId:function(){if(this.method=='POST'){var a=env_get('impid');if(a!==undefined){if(this.data.nctr===undefined)this.data.nctr={};this.data.nctr._impid=a;}}}});});