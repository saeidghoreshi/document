window.___jsl=window.___jsl||{};
window.___jsl.h=window.___jsl.h||'r;gc/21773286-02b1a9f6';
window.___gpq=[];
window.gapi=window.gapi||{};
window.gapi.plusone=window.gapi.plusone||(function(){
  function f(n){return function(){window.___gpq.push(n,arguments)}}
  return{go:f('go'),render:f('render')}})();
function __bsld(){var p=window.gapi.plusone=window.googleapisv0.plusone;var f;while(f=window.___gpq.shift()){
  p[f]&&p[f].apply(p,window.___gpq.shift())}
if (gadgets.config.get("gwidget")["parsetags"]!=="explicit"){gapi.plusone.go();}}
window['___jsl'] = window['___jsl'] || {};window['___jsl']['u'] = 'https:\/\/apis.google.com\/js\/plusone.js';window['___jsl']['f'] = ['googleapis.client','plusone'];var jsloader=window.jsloader||{};
var gapi=window.gapi||{};
(function(){function m(a,e,b,c){b=l(b).join(a);c&&c.length>0&&(b+=e+l(c).join(a));return b}function o(a){for(var e={},b=0;b<a.length;b++)e[a[b]]=!0;return e}function l(a){var e=[],b;for(b in o(a))e.push(b);return e.sort()}function u(){if(window.___gapisync===!0)return!0;for(var a=document.getElementsByTagName("meta"),e=0;e<a.length;++e){var b=a[e];if("generator"==b.getAttribute("name")&&"blogger"==b.getAttribute("content"))return!0}return!1}function p(a){for(var e=0;e<a.length;e++){var b=a[e],b=b.split("@"),
c=n,d,f=b[0].split("!");d=l(f[0].split(":"));f=f[1]&&l(f[1].split(":"));d=m(":","!",d,f);c[d]=b[1]}}function q(a){return(a=r.match(a))&&a[a.length-1]}function s(a){h=g=0;n={};j=[];i=window.console||window.opera&&window.opera.postError;r=a;if(!(a=q(v)||q(w)))a=(a=window.___jsl)&&a.h;a&&(a=a.split(";"),g=a[0],g==="s"?(h="https://ssl.gstatic.com/webclient/js",p(a.slice(1))):g==="i"?(h=a[1],p(a.slice(2))):g==="d"?(h=a[1],k=a[2],t=a[3]||"gcjs-3p"):g==="r"?(h="https://ssl.gstatic.com/webclient/js",k=a[1]):
g==="f"&&(h=a[1],k=a[2]))}var v=/\?[&|(\S*=\S*&)]*jsh=(\S*)#?/,w=/#[&|(\S*=\S*&)]*jsh=(\S*)/,x=/^https:\/\/ssl.gstatic.com\/webclient\/js(\/[a-zA-Z0-9_\-]+)*\/[a-zA-Z0-9_\-\.:!]+\.js$/,y=RegExp("^(http:|https:)?(\\/\\/)?([a-zA-Z0-9_\\-]+\\.)*google\\.com(:[0-9]+)?(\\/[a-zA-Z0-9_\\-]+)*\\/[a-zA-Z0-9_\\-\\.:!]+\\.js(\\?[a-zA-Z0-9_\\-&=%]*)?$"),g,h,t,k,n,j,i,r;s(document.location.href);jsloader.load=function(a,e){var b;if(!a||a.length==0)i&&i.warn("Cannot load empty features.");else{var c;c=o(j);for(var d=
!0,f=0;d&&f<a.length;f++)d=d&&c[a[f]];(c=d)?(c="Cannot load loaded features ["+a.join(",")+"].",i&&i.warn(c)):g==="s"||g==="i"?(c=a,(b=n[m(":","!",c,j)])?b=h+"/"+b+".js":(c="Cannot find features ["+c.join(",")+"], except ["+j.join(",")+"].",i&&i.warn(c),b=void 0)):g==="d"?(c=h+"/"+m(":","!",a,j),c+=".js?container="+t+"&c=2&jsload=0",k&&(c+="&r="+k),b=c):g==="r"||g==="f"?b=h+"/"+k+"/"+m("__","--",a,j)+".js":(c="Cannot respond for features ["+a.join(",")+"].",i&&i.warn(c))}c=a;d=e;if(b){if((f=window.___jsl)&&
d){if(f.c)throw"Cannot continue until a pending callback completes.";f.c=d;f.o=1}d=b;d=g==="s"||g==="r"?d.match(x):(f=(f=window.___jsl)&&(f.m=="dev"||f.m=="google"))&&d.match(y);if(!d)throw"Cannot load url "+b+".";u()?document.write('<script src="'+b+'"><\/script>'):(d=document.createElement("script"),d.setAttribute("src",b),document.getElementsByTagName("head")[0].appendChild(d));j=l(j.concat(c))}else d&&d()};jsloader.reinitialize_=function(a){s(a)}})();
gapi.load=function(a,b){jsloader.load(a.split(":"),b)};
gapi.load('googleapis.client:plusone', window['__bsld']);