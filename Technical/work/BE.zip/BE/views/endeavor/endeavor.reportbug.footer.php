<div class='btnset'>
    <div class='btn' ><button id='endeavor-report-bug-send'>Send</button></div>
	<div class='seperator'></div>
    <div class='btn' id=""><button id='endeavor-report-bug-close'>Close</button></div>
</div>
