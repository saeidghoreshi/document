<div class='btnset'>
    <div class='btn'  ><button id="endeavor-future-request-send">Send</button></div>
	<div class='seperator'></div>
    <div class='btn' ><button id="endeavor-future-request-close">Close</button></div>
</div>
