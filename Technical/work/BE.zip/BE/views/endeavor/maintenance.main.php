<style type="text/css">
.x-grid-row-over .x-grid-cell-inner {
    font-weight: bold;
}       
.x-grid-row .x-grid-cell-credit {
    background-color:#f1f2f4;
}

.x-grid-row .x-grid-cell-debit {
    background-color:#f1f2f4;
}

.link
{
    background-image: url(http://endeavor.servilliansolutionsinc.com/global_assets/silk/link.png) !important;
} 
.bullet_red
{
    background-image: url(http://endeavor.servilliansolutionsinc.com/global_assets/silk/bullet_red.png) !important;
} 
.bullet_green
{
    background-image: url(http://endeavor.servilliansolutionsinc.com/global_assets/silk/bullet_green.png) !important;
}
.bullet_yellow
{
    background-image: url(http://endeavor.servilliansolutionsinc.com/global_assets/silk/bullet_yellow.png) !important;
}
.transparent
{
    background: transparent!important;
}

</style>
<div class="ctr">
    <div id="container-main"></div>
</div>              
