<div class="btnset">
	<div class="btn">
		<button id="btn-close-about">Close</button>
	</div>
</div>
