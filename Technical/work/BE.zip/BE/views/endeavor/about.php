<div style="padding:5px;">

	<h1 style="color:#003366;">Spectrum &reg;</h1>
	<span style="color:#333333;font-weight:bold;">
		&copy; 2010 - <?=date('Y');?> Servillian Solutions Inc.<br/>
		<?=$_SERVER['SERVER_NAME']?><br/>
		v<?=VERSION?>
	</span>
	
	<br/>
	<br/>
	<table cellpadding="0" cellspacing="0" width="100%">
		<tr><td>Product Information</td><td><a href="http://playerspectrum.com/" target="_blank">http://www.servillian.com</a></td></tr>
		<tr><td colspan="2"><b>Developed By:</b></td></tr>
		<tr><td>Servillian Technology Ltd</td><td><a href="http://www.servillian.com" target="_blank">http://www.servillian.com</a></td></tr>
		
		<tr><td colspan="2"><br/><b>Developers:</b></td></tr>
		<tr><td>Bradley Holbrook</td><td>Development Director</td></tr>
		<tr><td>Allan Holbrook</td><td>Developer</td></tr>
		<tr><td>Ryan Goreshi</td><td>Developer</td></tr>
		<tr><td>Samson Bassett</td><td>Developer</td></tr>
		
		<tr><td colspan="2"><br/><b>Contributers:</b></td></tr>
		<tr><td>Debra Holbrook</td><td>Project Manager</td></tr>
		<tr><td>Bill Burrows</td><td>Marketing</td></tr>

		<tr><td colspan="2"><br/><b>Special Thanks To:</b></td></tr>
		<tr><td>Terry Sibbick</td><td>President, NSA Canada</td></tr>
		<tr><td>Ewan Webster</td><td>Business Manager, NSA Canada</td></tr>
		<tr><td>Diana Vietch</td><td>NSA Canada</td></tr>
		<tr><td>Mark James</td><td>Silk Icon Set</td></tr>
	</table>
	
	
</div>