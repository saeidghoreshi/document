<div class="btnset">
	<div class="btn">
		<button id="btn-process-endeavor-maintenance">Process</button>
	</div>

	<div class="seperator"></div>
	<div class="btn">
		<button id="btn-close-endeavor-maintenance">Close</button>
	</div>
</div>
