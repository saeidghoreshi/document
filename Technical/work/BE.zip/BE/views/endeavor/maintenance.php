
<?//   NOT USED ANYMORE         ?>
<div class="window" id="maintenance">
	
    <div id="mt-help" class="hidden">
    <p>Press 'Process' Below to read all classes and methods, creating method groups.</p>
    <p>This will take you to the screen for assigning Method Groups and Role Groups</p>
    
    
    
    </div>
    <div id="mt-content" >
    
    <table class="bigtable"><tr>
    
        <th class="half"><div class="label" id="m-status">Status: <span id="span-status"></span></div></th>
        <th class="half"><div id="m-dropdown"> </div></th>
    
    </tr><tr>
    <td ><table class="bigtable"><tr><td >
               <div class="datatable"><div id="dt-roles"></div></div></td></tr></table></td>
        
   
   <td class="cell" ><table class="bigtable"><tr><td  >
               <div class="datatable"><div id="dt-groups"></div></div></td></tr></table></td>
        
    </tr><tr>
    
         <td><div ><div id="dt-pag-roles"></div></div></td>
         <td><div ><div id="dt-pag-groups"></div></div></td>
    
    
    </tr></table>
    
    
    
    <table class="bigtable hidden" ><tr>
    <td class="label">View</td>
    <td class="label">Insert</td>
    <td class="label">Update</td>
    <td class="label">Delete</td>
    </tr><tr>
    <td ><select id="s-view" class="bigtable" >
    <option  value="none">None</option>
    <option value="own">Own</option>
    <option value="role" SELECTED>Role</option>
    <option value="all">All</option>
    </select></td>    
    <td><select id="s-insert" class="bigtable">
    <option value="none">None</option>
    <option value="own">Own</option>
    <option value="role" SELECTED>Role</option>
    <option value="all">All</option>
    </select></td>  
    <td><select  id="s-update" class="bigtable">
    <option value="none">None</option>
    <option value="own">Own</option>
    <option value="role" SELECTED>Role</option>
    <option value="all">All</option>
    </select></td>  
    <td><select id="s-del" class="bigtable">
    <option value="none">None</option>
    <option value="own">Own</option>
    <option value="role" SELECTED>Role</option>
    <option value="all">All</option>
    </select></td>  
    </tr></table>
    
    
    
    
    <p><span class="label">Double click a method group to load the permissions for that assignment.</span></p>
    
    <p><span class="label">You can save to more than one method group at once.</span></p>
    
    
    
    
    
    
    
    
    </div>
    
</div>
