<div class=window >
<table width="100%">
<tr>
    <td>
    <div>Title</div>
    <div class="input">
    <input type=text id="endeavor-report-bug-title" />
    </div>
    </td>
</tr>
<tr>
    <td>
    <div>Context</div>
    <div class="input">
    <textarea  id="endeavor-report-bug-context" cols="90" rows="20"></textarea>
    </div>
    </td>
</tr>
</table>
</div>
