<style type="text/css">
.x-grid-row-over .x-grid-cell-inner {
    font-weight: bold;
}       
</style>
<div class="ctr">
<div id="manage-list2"></div>
</div>     
