<style type="text/css">
.x-grid-row-over .x-grid-cell-inner {
    font-weight: bold;
}       
.x-grid-row .x-grid-cell-credit {
    background-color:#f1f2f4;
}

.x-grid-row .x-grid-cell-debit {
    background-color:#f1f2f4;
}       


.btn_inactive 
{
    opacity:0.6;
    filter:alpha(opacity=60);
}
.btn_active 
{
    opacity:1;
    filter:alpha(opacity=100); 
}   
.btn_inactive_red
{
    background-color: #f2f2f2 !important;
    background-image:'' !important;
    opacity:0.8;
    filter:alpha(opacity=80);
} 
.btn_shinysilver
{
    -moz-border-radius  : 3px 3px 3px 3px !important;
    background-color    : white !important;
    background-image    : -moz-linear-gradient(center top , #FFFFFF, #F9F9F9 48%, #E2E2E2 52%, #E7E7E7) !important;
    border-style        : solid !important;
    border-width        : 1px !important;
    padding             : 2px !important;
    border-color        : silver !important;
}
</style>

                                  
</style>

<div class="ctr">
<div id="manage-list-setup"></div>
</div>              
