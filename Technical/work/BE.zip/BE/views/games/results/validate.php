
<div class='window'>
	<table width='100%'>
	<tr>

		<td width='50%'>
			<div class='ctr' id='dg-result-games'>   </div>
		</td>
		<td width='50%'>
			<div class='ctr' id='dg-result-validate'></div>
		</td>

	</tr>
	</table>

</div>