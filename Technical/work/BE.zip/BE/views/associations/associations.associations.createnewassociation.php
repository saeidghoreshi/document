<table  width=100%>
<tr>
    <td width=50%>
                <div id="ASS-ca-user"></div>
    </td>
</tr>
<tr>
    <td width=50%>
                <div id="ASS-ca-name-DIV" class="form-field">
                    <div id="ASS-ca-name-label">Association Name</div>
                    <div id="ASS-ca-name-input" class="input">
                        <input type="text" id="ASS-ca-name"  />
                    </div>
                </div>
    </td>
   
</tr>
</table>
<span class="hidden" id="new-assn-success">Saved Successfully.</span> 

<span class="hidden" id="new-assn-fail">Error, an association with this name may already exist.</span> 