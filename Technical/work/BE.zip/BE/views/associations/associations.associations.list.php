<div class="datatable" width=400px>
<div id="dt-pag-associations"></div>
<div id="dt-associations"></div>
</div>