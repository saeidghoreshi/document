<div class="btnset">
    <div class="btn"><button id="cnl-back-btn">Back</button></div>
    <div class="seperator"></div>
	<div class="btn"><button id="btn-createleague-summary">View Summary</button></div>
	<div class="seperator"></div>
	<div class="btn"><button id="ASS-cl-btn-close">Close</button></div>
</div>
