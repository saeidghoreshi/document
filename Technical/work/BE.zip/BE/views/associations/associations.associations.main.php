<div id="tab-associations" class="yui-navset" >
    <ul class="yui-nav">
        <li class="selected"><a href="#tab1"><em>Associations</em></a></li>
        <li ><a href="#tab2"><em>Leagues</em></a></li>
        <li ><a href="#tab3"><em>Tournament</em></a></li>
        <li ><a href="#tab4"><em>Teams</em></a></li>
    </ul>            
    <div class="yui-content">
        <div><?=$associations?></div>
        <div><?=$leagues?></div>
        <div><?=$tournaments?></div>
        <div><?=$teams?></div>
       
    </div>    
</div>
