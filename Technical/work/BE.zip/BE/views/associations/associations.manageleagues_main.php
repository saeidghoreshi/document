<div id='MLeagues-loading'></div>  
<div id='MLeagues-window' class="window hidden">
    <div id="MLeagues-tab" class="yui-navset" >
        <ul class="yui-nav">
            <li class="selected"><a href="#tab0"><em>Leagues</em></a></li>
            <li ><a href="#tab1"><em>League Details</em></a></li>
            <li ><a href="#tab2"><em>League Manager</em></a></li>
        </ul>            
        <div class="yui-content">
            <div><?=$list_leagues?></div>
            <div><?=$edit_league?></div>   
            <div><?=$edit_manager?></div>   
            
        </div>  
        
    </div>
</div>
