<div class='btnset'>
	<div class='btn'><button id='MLeagues-back-btn'>Back</button></div>
	<div class='btn'><button id='MLeagues-save-btn'>Save Information</button></div>
	<div class='btn'><button id='MLeagues-save-league-btn'>Save Changes</button></div>
	<div class='btn'><button id='MLeagues-next-btn'>Edit manager</button></div>
	<div class='seperator'></div>
	<div class='btn'><button id='MLeagues-close-btn'>Close</button></div>
</div>