<div align="right">
<table cellpadding="0" cellspacing="0" >
<tr>                                               
    <td align="right"><div class="seperator"></div></td>
    <td align="right"><div id=c><button id="btn-close">Close</button></div></td>
</tr>
</table>                                     

</div>