<div class='window'>
 
	<div class='ctr'>
		<div id='dg-assoc-grid'></div>
	</div>

 
	<div class='ctr '> 
		<div id='dg-assoc-users' class='dghidden'></div>
	</div>

	<div class='ctr '> 
		<div id='dg-assoc-currency' class='dghidden'></div>
	</div>

	<div class='ctr '> 
		<div id='dg-assoc-domain' class='dghidden'></div>
	</div>
</div>