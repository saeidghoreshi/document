<style type="text/css">                                                                                                                                           
  .icon-zip { display:block; height: 22px; padding-left: 20px; background: transparent url(assets/images/layers.png) 0 -216px no-repeat; } 
  .htmlnodelabel { margin-left: 20px; } 
</style>
<div  id="tree-div"></div>