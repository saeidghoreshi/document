<p>
	<br/><br/>
	We're sorry to hear that you've lost your password; we hate it when that happens too. Lucky for you, we've got a copy
	and we're happy to share it with you!
</p>

<table class="receipt" cellpadding="1" cellspacing="5">
<tr>
	<td>
		<table class="recipient" cellpadding="4" cellspacing="1">
			<tr><th colspan="4">Credentials</th></tr>
			<tr>
				<td width="25%"><b>Your Password</b></td>
				<td width="75%"><?=@$password?></td>
			</tr>
		</table>
	</td>
</tr>
</table>