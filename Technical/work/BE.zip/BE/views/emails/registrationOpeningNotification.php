name:<?=$name?>
Email:<?=$email?>
League Name:<?=$leagueName?>
reg_start_date :<?=$reg_start_date?>
reg_end_date<?=$reg_end_date?>