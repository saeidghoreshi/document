<?php
echo '<pre>';
echo var_dump($info);
echo '</pre>';  
?>
