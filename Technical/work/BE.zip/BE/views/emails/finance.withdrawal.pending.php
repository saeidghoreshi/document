<html>
<head>
	<style>

	</style>
</head>
<body>

<h1>Pending Withdrawal Requires Your Approval</h1>

<p>Attn: <?=$name?></p>

<p>
	<b><?=$withdrawalname?></b> is requesting to withdrawal $<b><?=$total?></b> from your online league account. 
	$<b><?=$amount?></b> will be deposited into <b><?=$bankname?></b> account #<b>***** *** ***<?=substr($account,-4)?></b>
	owned by <b><?=$accountname?></b>.
</p>

<p>
	Because you are in the same treasurer role for <b><?=$assoc?></b>, you must approve this transaction before it can occur.
	To approve this transaction, please login at http://live.endeavor.servilliansolutionsinc.com. Once you are logged in, select
	the 'Treasury' tab, and then 'Pending Withdrawals'.
</p>

<p>Thank You.</p>

<p>
Customer Service<br/>
Servillian Solutions Inc<br/>
1 (800) ### - ####<br/>

support@ssi.com
</p>

</body>
</html>