<div class="window"  >
 <div class='ctr'>
<table width='100%' ><tr>
 
 	<td width='50%'>
    	<div style="padding-right:8px" id='dt-left-divisions' ></div>
 	</td>
 	
 	<td width='50%'>
    	<div style="padding-left: 8px" id='dt-right-divisions'></div> 	
 	</td>
 	
</tr></table>
</div>
</div>