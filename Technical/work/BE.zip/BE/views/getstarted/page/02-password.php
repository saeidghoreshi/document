<div class="frm-item">
	<div class="frm-container">
		<h1>Setup Spectrum Access</h1>
		<div class="frm-content">
			<p>
				If your are creating a new account, please select a login and password so that you can continue this process later without losing
				information you have entered during this process.
			</p>
			<p>
				If you have been assigned a login by an association administrator, please reset your password now for enhanced security.
			</p>
			<p>
				If neither of these cases apply to you and you already have a login and username confirmed, please press the next button at the bottom
				of this screen.
				<br/>
			</p>
			
			<div id="frm-gs-changepassword"></div>
		</div>
	</div>
</div>