<div class="frm-item">
	<div class="frm-container">
		<h1>Team Details</h1>
		<div class="frm-content">
			<div id='frm-gs-teamdetails'></div>
		</div>
	</div>
</div>