<div class="frm-item">
	<div class="frm-container">
		<h1>Confirm Your Details</h1>
		<div class="frm-content">
			<p>Please confirm your name, birthdate, and gender.</p>
			<div id="frm-gs-personaldetails"></div>
			<p class="info">
				We collect this information to ensure that we don't enter duplicate people into Spectrum.
			</p>
		</div>
	</div>
</div>