<div class="frm-item">
	<div class="frm-container">
		<h1>Association Details</h1>
		<div class="frm-content">
			<div id='frm-gs-assocdetails'></div>			
			
		</div>
	</div>
</div>