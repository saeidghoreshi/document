<div class="dyk-item">
	<div class="dyk-img"><img src="/assets/images/sidebar_169x465/security.jpg" width="359" height="406"/></div>
</div>
