
<center><h3>Your complete Online Sports Management System.</h3></center>


<p>
	Congratulations, you have found your way to <em>Spectrum</em> and your personal League Website.  Here you will find posted notices, your 
	League Contact details, Team information, Schedules, Game Results, Current Standings, and Association Announcements and information.
</p>
<p>
	From here, you can also link to your Association website and Servillian Technology, makers of this website and 
	<em>Spectrum</em> Online Sports Management.
</p>
<p>
	Welcome to the Spectrum System, please email us if you have any questions or if you require any assistance.
</p>

<br />

Thank you.

<br />
<br />

 
 
<p>
	<a href="mailto:support@servillian.com">service@playerspectrum.com</a>
</p>
<p>
	<a href="http://http://www.playerspectrum.com/">www.playerspectrum.com</a>
</p>