<html>
<head>
<style>
html, body{ margin:0px; }
body{ 
	background-image: url(/assets/images/login-loader.gif);
	background-repeat: no-repeat;
	background-position: center center;
}
</style>
</head>
<body>


<!--
This IFRAME is added to the welcome screen of the following sites:

http://brad.endeavor.servilliansolutionsinc.com
http://sam.endeavor.servilliansolutionsinc.com
http://ryan.endeavor.servilliansolutionsinc.com
http://beta.endeavor.servilliansolutionsinc.com
http://stage.spectrum.servilliansolutionsinc.com
http://live.spectrum.servilliansolutionsinc.com

-->
</body>
</html>