<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');//important security for all libraries
    
class Tournament extends Scheduler
{
	function __construct()
    {                      
        parent::Scheduler();//extend  library
         
    }
    
    
    
    
    
}
