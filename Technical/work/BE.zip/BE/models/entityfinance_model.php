<?php

require_once('./endeavor/models/finance_model.php');
class EntityFinance_model extends Finance_model
{
	
	public function get_wallet_balance($entity)
	{
		
	}
	
}

?>
