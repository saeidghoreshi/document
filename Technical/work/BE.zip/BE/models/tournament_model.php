<?php
require_once('./endeavor/models/schedule_model.php');
class Tournament_model extends Schedule_model
{
 
	
	
	
	
	
}