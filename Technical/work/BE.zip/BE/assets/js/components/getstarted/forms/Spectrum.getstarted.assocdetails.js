//Spectrum.getstarted.assocdetails.js






//   renderTo: 'frm-gs-assocdetails'