
var customFieldsGrid=new customFieldsGridClass();
customFieldsGrid.init();
