<?php

include_once "class.Chase.php";
// collect all posted data -------------
$uname  			= isset($_POST['uname']) ? $_POST['uname'] : '';
$passwd1			= isset($_POST['passwd1']) ? $_POST['passwd1'] : '';
$passwd2  			= isset($_POST['passwd2']) ? $_POST['passwd2'] : '';
$title  			= isset($_POST['title']) ? $_POST['title'] : '';
$firstname  		= isset($_POST['firstname']) ? $_POST['firstname'] : '';
$lastname  			= isset($_POST['lastname']) ? $_POST['lastname'] : '';
$b_address  		= isset($_POST['b_address']) ? $_POST['b_address'] : '';	
$b_address_2		= isset($_POST['b_address_2']) ? $_POST['b_address_2'] : '';  
$b_city  			= isset($_POST['b_city']) ? $_POST['b_city'] : '';
$b_state 			= isset($_POST['b_state']) ? $_POST['b_state'] : ''; 
$b_country  		= isset($_POST['b_country']) ? $_POST['b_country'] : '';
$b_zipcode  		= isset($_POST['b_zipcode']) ? $_POST['b_zipcode'] : '';
$phone  			= isset($_POST['phone']) ? $_POST['phone'] : '';

$paymentid  		= isset($_POST['paymentid']) ? $_POST['paymentid'] : '';
$card_type  		= isset($_POST['card_type']) ? $_POST['card_type'] : '';
$card_name  		= isset($_POST['card_name']) ? $_POST['card_name'] : '';
$card_number		= isset($_POST['card_number']) ? $_POST['card_number'] : ''; 
$cvv2				= isset($_POST['cvv2']) ? $_POST['cvv2'] : ''; 
$card_expire_Month  = isset($_POST['card_expire_Month']) ? $_POST['card_expire_Month'] : '';
$card_expire_Year  	= isset($_POST['card_expire_Year']) ? $_POST['card_expire_Year'] : '';

 // currecny and amount
$currency 		= isset($_POST['currency']) ? $_POST['currency'] : '';
$amount  		= isset($_POST['amount']) ? $_POST['amount'] : '';




// create object for chase ------------------------------------
$obj_chase = new Chase($currency);
	
// Assign Credit Card Information
$obj_chase->AccountNum 	= $card_number;
$card_expire_str		= str_pad($card_expire_Month, 2, "0", STR_PAD_LEFT).substr($card_expire_Year, 2);
$obj_chase->Exp			= $card_expire_str;
$obj_chase->CardSecVal  = $cvv2;
$obj_chase->CCtype		= $card_type;
	
// Assign AVS Information
$obj_chase->AVSname		= $card_name;
$obj_chase->AVSzip		= $b_zipcode;
$obj_chase->AVSaddress1	= $b_address;	
$obj_chase->AVSaddress2	= $b_address_2;
$obj_chase->AVScity		= $b_city;
$obj_chase->AVSstate	= $b_state;
$obj_chase->AVSphoneNum	= $phone;
	

// Assign Other information
$obj_chase->Email 		= $uname;
$obj_chase->Phone 		= $phone;
$obj_chase->Comments	= 'Email - '.$uname.' | Phone - '.$phone;
	

//Assign Amount
$obj_chase->Amount		= str_replace(".", "", $amount);

// call function to post an order ------
if($obj_chase->post_an_order())	
{
	echo "order Success ----";
}
else
{
	echo "order Fail -----";

	$errors_in_processing = $obj_chase->error;
	if(is_array($errors_in_processing))
	{
		$total_errors = count($errors_in_processing);
		for($i=0; $i<$total_errors; $i++)
		{
			$str_error.= "<br />".$errors_in_processing[$i];
		}
	}
}