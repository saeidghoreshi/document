<?php
/**
 * Desc    This is saple class to use for posting an order through chase payment gateway,
 *         Also it contains functions for making request VOID or REFUND. 
 * @author Roshan P. Shahare, Pune, India.
 */
class Chase
{
	private $_IndustryType;
	private $_MessageType;
	private $_BIN;
	private $_MerchantID;
	private $_TerminalID;
	
	
	// Currency Information
	private $_CurrencyCode;
	private $_CurrencyExponent;
	
	
	// Chase settings url etc
	private $_chase_gateway_url;
	
	
	// Card Details
	public $CardBrand;
	public $AccountNum;
	public $Exp;
	public $CardSecValInd;
	public $CardSecVal;
	public $CCtype;
	
	
	// AVS Information
	public $AVSname;
	public $AVSzip; // 25541
	public $AVSaddress1; // 123 Test Street
	public $AVSaddress2; // Suite 350
	public $AVScity; // Test City
	public $AVSstate; // 
	public $AVSphoneNum; // 800456451212
			
	
	// OREDER Information
	public $OrderID;
	public $Amount;
	
	
	// OTHER Information
	public $Comments;
	public $Email;
	public $Phone;
	
	public $error;
	public $email_msg_to_send = '';
	public $receipt_msg_to_show = '';
	
	
	// Varibales to track
	public $chase_QuickResponse = '';
	public $chase_ProcStatus	= '';
	public $chase_StatusMsg 	= '';
	
	
	//Responses from varius request like NewOrder, Reversal(VOID), REFUND
	public $arr_NewOrder_response;  // New Order 
	public $arr_Reversal_response;  // VOID operation
	public $arr_Refund_response;    // Refund type	
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $currency
	 */
	public function __construct($currency)
	{
		$this->_IndustryType 		= 'EC';
		$this->_MessageType  		= 'AC';
		$this->_BIN			 		= '000001';		
		if($currency == 'AUD'){ $this->_MerchantID	= '022225';}		// ADD your merchant id ---------provided by chase
		if($currency == 'NZD'){ $this->_MerchantID	= '022223';}        // ADD your merchant id ---------provided by chase
		$this->_TerminalID			= '001';
		
		$this->_CurrencyExponent	= '2';
		if($currency == 'NZD')
		{$this->_CurrencyCode		= '554';}
		if($currency == 'AUD')
		{$this->_CurrencyCode		= '036';}		
		
		list($server) = split("[:/]", $_SERVER['HTTP_HOST']);
		/************** ADD YOUR website name ********************************/
		if($server == 'www.liveserver.com')  // add your server name devlopment or live -----
		{
			// live url on production server
			$this->_chase_gateway_url = 'https://orbital1.paymentech.net/authorize';
			
			// assign test mode
			//$this->_chase_gateway_url = 'https://orbitalvar1.paymentech.net/authorize';
		}
		elseif ($server == 'development.server.com')   // add your server name devlopment or live -----
		{
			// testing url on development server
			$this->_chase_gateway_url = 'https://orbitalvar1.paymentech.net/authorize';
		}
		else 
		{
			// Default url
			$this->_chase_gateway_url = 'https://orbital1.paymentech.net/authorize';
			// assign test mode
			$this->_chase_gateway_url = 'https://orbitalvar1.paymentech.net/authorize';
		}
	}
	
	
	/**
	 * parse response of gateway
	 * 
	 * @param string $xmlResponse
	 * @return array
	 */
	
	public function parseXmlResponse($xmlResponse)
	{
		$newResArr = array();
		foreach($xmlResponse as $val)
		{
			$tagval=$val['tag'];
			if(($val['tag']!='Response') && ($val['tag']!='NewOrderResp'))	{	
				if(isset($val['value'])){
					$newResArr[$tagval]=$val['value'];
					}
					else{
					$newResArr[$tagval]='';
					}
				}
		}
	    return $newResArr;
	}
	
	/**
	 * Enter description here...
	 *
	 * @return unknown
	 */
	private function generate_order_xml()
	{
					
		$xml = 
			"<?xml version=\"1.0\" encoding=\"UTF-8\"?>
			<Request>
			<NewOrder>
			<IndustryType>".$this->_IndustryType."</IndustryType>
			<MessageType>".$this->_MessageType."</MessageType>
			<BIN>".$this->_BIN."</BIN>
			<MerchantID>".$this->_MerchantID."</MerchantID>
			<TerminalID>".$this->_TerminalID."</TerminalID>
			<CardBrand></CardBrand>
			<AccountNum>".$this->AccountNum."</AccountNum>";
			if($this->CCtype == 'VISA' || $this->CCtype == 'MC')
			{
				$xml .= "<CardSecValInd>1</CardSecValInd>";
				$xml .="<CardSecVal>".$this->CardSecVal."</CardSecVal>";
			}		
		$xml .="<Exp>".$this->Exp."</Exp>
			<CurrencyCode>".$this->_CurrencyCode."</CurrencyCode>
			<CurrencyExponent>2</CurrencyExponent>			
			<AVSzip>".$this->AVSzip."</AVSzip>
			<AVSaddress1>".$this->AVSaddress1."</AVSaddress1>
			<AVSaddress2>".$this->AVSaddress2."</AVSaddress2>
			<AVScity>".$this->AVScity."</AVScity>
			<AVSstate></AVSstate>
			<AVSphoneNum>".$this->AVSphoneNum."</AVSphoneNum>
			<AVSname>".$this->AVSname."</AVSname>			
			<OrderID>".time()."</OrderID>
			<Amount>".$this->Amount."</Amount>
			<Comments>".$this->Comments."</Comments>
			</NewOrder>
			</Request>";
		return $xml;
	}
	
	/**
	 * Enter description here...
	 *
	 * @return unknown
	 */
	public function post_an_order()
	{
		$xml = $this->generate_order_xml();
				
		$header= "POST /AUTHORIZE HTTP/1.0\r\n";
		$header.= "MIME-Version: 1.0\r\n";
		$header.= "Content-type: application/PTI46\r\n";
		$header.= "Content-length: ".strlen($xml)."\r\n";
		$header.= "Content-transfer-encoding: text\r\n";
		$header.= "Request-number: 1\r\n";
		$header.= "Document-type: Request\r\n";
		$header.= "Interface-Version: Test 1.4\r\n";
		$header.= "Connection: close \r\n\r\n"; 
		
			
		$header.= $xml;
				
		/** CURL Implementation **/

		$ch = curl_init();
		//curl_setopt($ch, CURLOPT_URL, "https://orbitalvar1.paymentech.net/authorize");
		curl_setopt($ch, CURLOPT_URL, $this->_chase_gateway_url);		
		curl_setopt($ch, CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $header);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);					
		
		$response = curl_exec($ch);    	
		
		if (curl_errno($ch))
		{
		   //print curl_error($ch);
		}
		else
		{
		   curl_close($ch);
		}
				   		   
		$xml_parser = xml_parser_create();
		xml_parser_set_option($xml_parser,XML_OPTION_CASE_FOLDING,0);
		xml_parser_set_option($xml_parser,XML_OPTION_SKIP_WHITE,1);
		xml_parse_into_struct($xml_parser, $response, $vals,$index);
		xml_parser_free($xml_parser);
		
		/*****************/	
		$parsedResArr = $this->parseXmlResponse($vals);
		
		$this->arr_NewOrder_response = $parsedResArr;
		/*echo "<pre>";
		print_r($parsedResArr);
		echo "</pre>";*/
		
		
		if($parsedResArr['ProcStatus'] == '0' && $parsedResArr['ApprovalStatus'] == '1' && $parsedResArr['RespCode'] == '00')
		{
			/*
			It is the only element that is returned in
			all response scenarios. It identifies whether transactions
			have successfully passed all of the Gateway edit checks.
			0 � Success
			*/
			//echo "successful";
			return true;			
		}
		else 
		{
			// First Track Varibales
			$this->chase_QuickResponse 	= $parsedResArr['QuickResponse'];
			$this->chase_ProcStatus 	= $parsedResArr['ProcStatus'];
			$this->chase_StatusMsg		= $parsedResArr['StatusMsg'];
			
			
			//echo "unsuccessful";
			switch($parsedResArr['RespCode'])
			{
				case '04' :
				{
					$this->error[] = 'Card is in Decline State';	
					break;
				}
				case '05' :
				{
					$this->error[] =  'Card is not Honored';
					break;
				}
				case '06' :
				{
					$this->error[] = 'Unsupported Error in Cart';
					break;
				}
				case '13' :
				{
					$this->error[] = 'Bad Amount';
					break;
				}
				case '42' :
				{
					$this->error[] = 'Account Not Active';
					break;
				}
				case '33' :
				{
					$this->error[] = 'Card is expired';
					break;
				}
				case '68' :
				{
					$this->error[] = 'Invalid CC Number';
					break;
				}
				default	:
				{
					break;
					//$this->error[] ='Resp Code - '.$parsedResArr['RespCode'];					
				}
			}
			
			if($parsedResArr['CVV2RespCode']!='M')
			{
				
				switch($parsedResArr['CVV2RespCode'])
				{
					case 'N' :
					{
						$this->error[] = 'The CVV is not matched  with the Card No';
						break;
					}
					case 'P' :
					{
						$this->error[] = 'The CVV is Not Processed';
						break;
					}
					case 'S' :
					{
						$this->error[] = 'The CVV Should have been present';
						break;
					}
					case 'U' :
					{
						$this->error[] = 'The CVV is Unsupported by Issuer/Issuer unable to process request';
						break;
					}
					case 'I' :
					{
						break;
					}
					case 'Y' :
					{
						$this->error[] = 'The CVV is Invalid';
						break;
					}
					default	: break; //$this->error[] = 'CVV2RespCode Code - '.$parsedResArr['CVV2RespCode']; 
								
				}			
			}
			
			switch($parsedResArr['AVSRespCode'])
			{
				case 'D' :	
				{
					$this->error[]	= 'The Zipcode is not Match with the Card';
					break;
				}
				case 'G' :
				{										   
					$this->error[]	= 'The Zipcode is not Match with the Card';						
					break;
				}
				case '4' :
				{
					$this->error[]	= 'Issuer does not participate in AVS';
					break;
				}				
				default	: break;//$this->error[] = 'AVSRespCode Code - '.$parsedResArr['AVSRespCode'];
			}	
			
			return false;			
		}		
	}

	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $OrderID
	 * @param unknown_type $TxRefNum
	 * @param unknown_type $TxRefIdx
	 * @param unknown_type $AdjustedAmt
	 * @return unknown
	 */
	// Reveses the order before submitting the batch.
	public function void_an_order($OrderID, $TxRefNum, $TxRefIdx, $AdjustedAmt)
	{
		
		$AdjustedAmt = str_replace(".", "", $AdjustedAmt);
		$xml = 
		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>
		<Request>
		<Reversal>		
		<TxRefNum>".$TxRefNum."</TxRefNum>
		<TxRefIdx>".$TxRefIdx."</TxRefIdx>
		<AdjustedAmt>".$AdjustedAmt."</AdjustedAmt>	
		<OrderID>".$OrderID."</OrderID>
		<BIN>".$this->_BIN."</BIN>
		<MerchantID>".$this->_MerchantID."</MerchantID>
		<TerminalID>".$this->_TerminalID."</TerminalID>
		<ReversalRetryNumber></ReversalRetryNumber>
		</Reversal>
		</Request>";
			
		$header= "POST /AUTHORIZE HTTP/1.0\r\n";
		$header.= "MIME-Version: 1.0\r\n";
		$header.= "Content-type: application/PTI46\r\n";
		$header.= "Content-length: ".strlen($xml)."\r\n";
		$header.= "Content-transfer-encoding: text\r\n";
		$header.= "Request-number: 1\r\n";
		$header.= "Document-type: Request\r\n";
		$header.= "Interface-Version: Test 1.4\r\n";
		$header.= "Connection: close \r\n\r\n"; 
		
		$header.= $xml;
				
		/** CURL Implementation **/
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->_chase_gateway_url);		
		curl_setopt($ch, CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $header);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);					
		
		$response = curl_exec($ch);    	
		
		if (curl_errno($ch))
		{
		   //print curl_error($ch);
		}
		else
		{
		   curl_close($ch);
		}
				   		   
		$xml_parser = xml_parser_create();
		xml_parser_set_option($xml_parser,XML_OPTION_CASE_FOLDING,0);
		xml_parser_set_option($xml_parser,XML_OPTION_SKIP_WHITE,1);
		xml_parse_into_struct($xml_parser, $response, $vals,$index);
		xml_parser_free($xml_parser);
		
		/*****************/	
		$parsedResArr = $this->parseXmlResponse($vals);

		$this->arr_Reversal_response = 	$parsedResArr;		
		
		//print_r($this->arr_Reversal_response);
		
		if($parsedResArr['ProcStatus'] == 0)
		{
			return true;
		}
		else 
		{
			return false;
		}
	}
	
	
	/**
	 * Enter description here...
	 *
	 * @param unknown_type $OrderID
	 * @param unknown_type $Amount
	 * @param unknown_type $TxRefNum
	 * @return unknown
	 */
	public function refund_an_order($OrderID, $Amount, $TxRefNum)
	{
		$Amount = str_replace(".", "", $Amount);
		$xml = 
		"<?xml version=\"1.0\" encoding=\"UTF-8\"?>
	 	<Request>
		<NewOrder>
		<IndustryType>".$this->_IndustryType."</IndustryType>
		<MessageType>R</MessageType>
		<BIN>".$this->_BIN."</BIN>
		<MerchantID>".$this->_MerchantID."</MerchantID>
		<TerminalID>".$this->_TerminalID."</TerminalID>
		<OrderID>".$OrderID."</OrderID>
		<Amount>".$Amount."</Amount>
		<TxRefNum>".$TxRefNum."</TxRefNum>
		</NewOrder>
		</Request>";
			
		$header= "POST /AUTHORIZE HTTP/1.0\r\n";
		$header.= "MIME-Version: 1.0\r\n";
		$header.= "Content-type: application/PTI46\r\n";
		$header.= "Content-length: ".strlen($xml)."\r\n";
		$header.= "Content-transfer-encoding: text\r\n";
		$header.= "Request-number: 1\r\n";
		$header.= "Document-type: Request\r\n";
		$header.= "Interface-Version: Test 1.4\r\n";
		$header.= "Connection: close \r\n\r\n"; 
		
		$header.= $xml;
				
		/** CURL Implementation **/
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $this->_chase_gateway_url);		
		curl_setopt($ch, CURLOPT_HEADER, false); 
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $header);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);					
		
		$response = curl_exec($ch);    	
		
		if (curl_errno($ch))
		{
		   //print curl_error($ch);
		}
		else
		{
		   curl_close($ch);
		}
				   		   
		$xml_parser = xml_parser_create();
		xml_parser_set_option($xml_parser,XML_OPTION_CASE_FOLDING,0);
		xml_parser_set_option($xml_parser,XML_OPTION_SKIP_WHITE,1);
		xml_parse_into_struct($xml_parser, $response, $vals,$index);
		xml_parser_free($xml_parser);
		
		/*****************/	
		$parsedResArr = $this->parseXmlResponse($vals);

		$this->arr_Refund_response = 	$parsedResArr;		
		
		//print_r($this->arr_Refund_response);
		
		if($parsedResArr['ProcStatus'] == '0') // && $parsedResArr['ApprovalStatus'] == '1' && $parsedResArr['RespCode'] == '00')
		{
			return true;
		}
		else 
		{
			return false;
		}		
	}	
}